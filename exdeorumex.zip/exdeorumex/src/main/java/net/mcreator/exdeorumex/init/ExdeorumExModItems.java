
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.exdeorumex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.exdeorumex.item.WoodenShearsItem;
import net.mcreator.exdeorumex.item.WoodenCompressHammerItem;
import net.mcreator.exdeorumex.item.WoodenCompressCrookItem;
import net.mcreator.exdeorumex.item.StoneStickItem;
import net.mcreator.exdeorumex.item.StoneCompressHammerItem;
import net.mcreator.exdeorumex.item.StoneCompressCrookItem;
import net.mcreator.exdeorumex.item.StoneChipsItem;
import net.mcreator.exdeorumex.item.SteelIngotItem;
import net.mcreator.exdeorumex.item.SteelHammerItem;
import net.mcreator.exdeorumex.item.SandChipsItem;
import net.mcreator.exdeorumex.item.PearItem;
import net.mcreator.exdeorumex.item.PeachItem;
import net.mcreator.exdeorumex.item.NutsItem;
import net.mcreator.exdeorumex.item.NetherrackChipsItem;
import net.mcreator.exdeorumex.item.NetheriteCompressHammerItem;
import net.mcreator.exdeorumex.item.LeaveItem;
import net.mcreator.exdeorumex.item.IronCompressHammerItem;
import net.mcreator.exdeorumex.item.GravelChipsItem;
import net.mcreator.exdeorumex.item.GoldenCompressHammerItem;
import net.mcreator.exdeorumex.item.FlintShearsItem;
import net.mcreator.exdeorumex.item.FlintChipsItem;
import net.mcreator.exdeorumex.item.EndChipsItem;
import net.mcreator.exdeorumex.item.DustChipsItem;
import net.mcreator.exdeorumex.item.DoubleNetheriteCompressHammerItem;
import net.mcreator.exdeorumex.item.DoubleFlintShearsItem;
import net.mcreator.exdeorumex.item.DoubleCompresStoneCrookItem;
import net.mcreator.exdeorumex.item.DobleDiamonCompressHammerItem;
import net.mcreator.exdeorumex.item.DirtChipsItem;
import net.mcreator.exdeorumex.item.DiamonCompressHammerItem;
import net.mcreator.exdeorumex.item.DeepslateChipsItem;
import net.mcreator.exdeorumex.item.CookedNutsItem;
import net.mcreator.exdeorumex.item.CompressStringItem;
import net.mcreator.exdeorumex.item.CompressSilkWormItem;
import net.mcreator.exdeorumex.item.CompressSeedsItem;
import net.mcreator.exdeorumex.item.CompressSaplingItem;
import net.mcreator.exdeorumex.item.BlackstoneChipsItem;
import net.mcreator.exdeorumex.ExdeorumExMod;

public class ExdeorumExModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ExdeorumExMod.MODID);
	public static final RegistryObject<Item> COMPRESS_DIRT = block(ExdeorumExModBlocks.COMPRESS_DIRT);
	public static final RegistryObject<Item> COMPRESS_GRAVEL = block(ExdeorumExModBlocks.COMPRESS_GRAVEL);
	public static final RegistryObject<Item> COMPRESS_SAND = block(ExdeorumExModBlocks.COMPRESS_SAND);
	public static final RegistryObject<Item> COMPRESS_DUST = block(ExdeorumExModBlocks.COMPRESS_DUST);
	public static final RegistryObject<Item> COMPRESS_CRUSHED_NETHERRACK = block(ExdeorumExModBlocks.COMPRESS_CRUSHED_NETHERRACK);
	public static final RegistryObject<Item> COMPRESS_CRUSHED_END_STONE = block(ExdeorumExModBlocks.COMPRESS_CRUSHED_END_STONE);
	public static final RegistryObject<Item> COMPRESS_CRUSHED_DEEPSLATE = block(ExdeorumExModBlocks.COMPRESS_CRUSHED_DEEPSLATE);
	public static final RegistryObject<Item> COMPRESS_CRUSHED_BLACKSTONE = block(ExdeorumExModBlocks.COMPRESS_CRUSHED_BLACKSTONE);
	public static final RegistryObject<Item> STONE_CHIPS = REGISTRY.register("stone_chips", () -> new StoneChipsItem());
	public static final RegistryObject<Item> FLINT_CHIPS = REGISTRY.register("flint_chips", () -> new FlintChipsItem());
	public static final RegistryObject<Item> DIRT_CHIPS = REGISTRY.register("dirt_chips", () -> new DirtChipsItem());
	public static final RegistryObject<Item> GRAVEL_CHIPS = REGISTRY.register("gravel_chips", () -> new GravelChipsItem());
	public static final RegistryObject<Item> SAND_CHIPS = REGISTRY.register("sand_chips", () -> new SandChipsItem());
	public static final RegistryObject<Item> DUST_CHIPS = REGISTRY.register("dust_chips", () -> new DustChipsItem());
	public static final RegistryObject<Item> NETHERRACK_CHIPS = REGISTRY.register("netherrack_chips", () -> new NetherrackChipsItem());
	public static final RegistryObject<Item> END_CHIPS = REGISTRY.register("end_chips", () -> new EndChipsItem());
	public static final RegistryObject<Item> DEEPSLATE_CHIPS = REGISTRY.register("deepslate_chips", () -> new DeepslateChipsItem());
	public static final RegistryObject<Item> BLACKSTONE_CHIPS = REGISTRY.register("blackstone_chips", () -> new BlackstoneChipsItem());
	public static final RegistryObject<Item> COMPRESS_LEAVES = block(ExdeorumExModBlocks.COMPRESS_LEAVES);
	public static final RegistryObject<Item> COMPRESS_SILK_WORM = REGISTRY.register("compress_silk_worm", () -> new CompressSilkWormItem());
	public static final RegistryObject<Item> COMPRESS_STRING = REGISTRY.register("compress_string", () -> new CompressStringItem());
	public static final RegistryObject<Item> COMPRESS_SEEDS = REGISTRY.register("compress_seeds", () -> new CompressSeedsItem());
	public static final RegistryObject<Item> COMPRESS_SAPLING = REGISTRY.register("compress_sapling", () -> new CompressSaplingItem());
	public static final RegistryObject<Item> LEAVE = REGISTRY.register("leave", () -> new LeaveItem());
	public static final RegistryObject<Item> PEAR = REGISTRY.register("pear", () -> new PearItem());
	public static final RegistryObject<Item> PEACH = REGISTRY.register("peach", () -> new PeachItem());
	public static final RegistryObject<Item> NUTS = REGISTRY.register("nuts", () -> new NutsItem());
	public static final RegistryObject<Item> COOKED_NUTS = REGISTRY.register("cooked_nuts", () -> new CookedNutsItem());
	public static final RegistryObject<Item> STONE_STICK = REGISTRY.register("stone_stick", () -> new StoneStickItem());
	public static final RegistryObject<Item> WOODEN_COMPRESS_CROOK = REGISTRY.register("wooden_compress_crook", () -> new WoodenCompressCrookItem());
	public static final RegistryObject<Item> STONE_COMPRESS_CROOK = REGISTRY.register("stone_compress_crook", () -> new StoneCompressCrookItem());
	public static final RegistryObject<Item> DOUBLE_COMPRES_STONE_CROOK = REGISTRY.register("double_compres_stone_crook", () -> new DoubleCompresStoneCrookItem());
	public static final RegistryObject<Item> STEEL_HAMMER = REGISTRY.register("steel_hammer", () -> new SteelHammerItem());
	public static final RegistryObject<Item> WOODEN_COMPRESS_HAMMER = REGISTRY.register("wooden_compress_hammer", () -> new WoodenCompressHammerItem());
	public static final RegistryObject<Item> STONE_COMPRESS_HAMMER = REGISTRY.register("stone_compress_hammer", () -> new StoneCompressHammerItem());
	public static final RegistryObject<Item> IRON_COMPRESS_HAMMER = REGISTRY.register("iron_compress_hammer", () -> new IronCompressHammerItem());
	public static final RegistryObject<Item> GOLDEN_COMPRESS_HAMMER = REGISTRY.register("golden_compress_hammer", () -> new GoldenCompressHammerItem());
	public static final RegistryObject<Item> DIAMON_COMPRESS_HAMMER = REGISTRY.register("diamon_compress_hammer", () -> new DiamonCompressHammerItem());
	public static final RegistryObject<Item> DOBLE_DIAMON_COMPRESS_HAMMER = REGISTRY.register("doble_diamon_compress_hammer", () -> new DobleDiamonCompressHammerItem());
	public static final RegistryObject<Item> NETHERITE_COMPRESS_HAMMER = REGISTRY.register("netherite_compress_hammer", () -> new NetheriteCompressHammerItem());
	public static final RegistryObject<Item> DOUBLE_NETHERITE_COMPRESS_HAMMER = REGISTRY.register("double_netherite_compress_hammer", () -> new DoubleNetheriteCompressHammerItem());
	public static final RegistryObject<Item> WOODEN_SHEARS = REGISTRY.register("wooden_shears", () -> new WoodenShearsItem());
	public static final RegistryObject<Item> FLINT_SHEARS = REGISTRY.register("flint_shears", () -> new FlintShearsItem());
	public static final RegistryObject<Item> DOUBLE_FLINT_SHEARS = REGISTRY.register("double_flint_shears", () -> new DoubleFlintShearsItem());
	public static final RegistryObject<Item> COBBLESTONE_MACHINE = block(ExdeorumExModBlocks.COBBLESTONE_MACHINE);
	public static final RegistryObject<Item> COBBLESTONE_MACHINES_2 = block(ExdeorumExModBlocks.COBBLESTONE_MACHINES_2);
	public static final RegistryObject<Item> COBBLESTONE_MACHINE_3 = block(ExdeorumExModBlocks.COBBLESTONE_MACHINE_3);
	public static final RegistryObject<Item> LAVA_BLOCK = block(ExdeorumExModBlocks.LAVA_BLOCK);
	public static final RegistryObject<Item> WITCH_DIRT = block(ExdeorumExModBlocks.WITCH_DIRT);
	public static final RegistryObject<Item> DIRT_MACHINE = block(ExdeorumExModBlocks.DIRT_MACHINE);
	public static final RegistryObject<Item> DIRT_MACHINE_2 = block(ExdeorumExModBlocks.DIRT_MACHINE_2);
	public static final RegistryObject<Item> DIRT_MACHINE_3 = block(ExdeorumExModBlocks.DIRT_MACHINE_3);
	public static final RegistryObject<Item> COMPRESS_STONE_1X = block(ExdeorumExModBlocks.COMPRESS_STONE_1X);
	public static final RegistryObject<Item> COMPRESS_STONE_2X = block(ExdeorumExModBlocks.COMPRESS_STONE_2X);
	public static final RegistryObject<Item> COMPRESS_STONE_3X = block(ExdeorumExModBlocks.COMPRESS_STONE_3X);
	public static final RegistryObject<Item> COMPRESS_STONE_4X = block(ExdeorumExModBlocks.COMPRESS_STONE_4X);
	public static final RegistryObject<Item> COMPRESS_COBBLESTONE_1X = block(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_1X);
	public static final RegistryObject<Item> COMPRESS_COBBLESTONE_2X = block(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_2X);
	public static final RegistryObject<Item> COMPRESS_COBBLESTONE_3X = block(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_3X);
	public static final RegistryObject<Item> COMPRESS_COBBLESTONE_4X = block(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_4X);
	public static final RegistryObject<Item> COMPRESS_DIRT_2X = block(ExdeorumExModBlocks.COMPRESS_DIRT_2X);
	public static final RegistryObject<Item> COMPRESS_DIRT_3X = block(ExdeorumExModBlocks.COMPRESS_DIRT_3X);
	public static final RegistryObject<Item> COMPRESS_DIRT_4X = block(ExdeorumExModBlocks.COMPRESS_DIRT_4X);
	public static final RegistryObject<Item> COMPRESS_SAND_2X = block(ExdeorumExModBlocks.COMPRESS_SAND_2X);
	public static final RegistryObject<Item> COMPRESS_SAND_3X = block(ExdeorumExModBlocks.COMPRESS_SAND_3X);
	public static final RegistryObject<Item> COMPRESS_SAND_4X = block(ExdeorumExModBlocks.COMPRESS_SAND_4X);
	public static final RegistryObject<Item> COMPRESS_DUST_2X = block(ExdeorumExModBlocks.COMPRESS_DUST_2X);
	public static final RegistryObject<Item> COMPRESS_DUST_3X = block(ExdeorumExModBlocks.COMPRESS_DUST_3X);
	public static final RegistryObject<Item> COMPRESS_DUST_4X = block(ExdeorumExModBlocks.COMPRESS_DUST_4X);
	public static final RegistryObject<Item> COMPRESS_GRAVEL_2X = block(ExdeorumExModBlocks.COMPRESS_GRAVEL_2X);
	public static final RegistryObject<Item> COMPRESS_GRAVEL_3X = block(ExdeorumExModBlocks.COMPRESS_GRAVEL_3X);
	public static final RegistryObject<Item> COMPRESS_GRAVEL_4X = block(ExdeorumExModBlocks.COMPRESS_GRAVEL_4X);
	public static final RegistryObject<Item> STEEL_INGOT = REGISTRY.register("steel_ingot", () -> new SteelIngotItem());
	public static final RegistryObject<Item> STEEL_BLOCK = block(ExdeorumExModBlocks.STEEL_BLOCK);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
