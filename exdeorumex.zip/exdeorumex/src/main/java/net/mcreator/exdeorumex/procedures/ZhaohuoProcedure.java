package net.mcreator.exdeorumex.procedures;

import net.minecraft.world.entity.Entity;

public class ZhaohuoProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(1);
	}
}
