
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.exdeorumex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.exdeorumex.block.entity.DirtMachineBlockEntity;
import net.mcreator.exdeorumex.block.entity.DirtMachine3BlockEntity;
import net.mcreator.exdeorumex.block.entity.DirtMachine2BlockEntity;
import net.mcreator.exdeorumex.block.entity.CobblestoneMachines2BlockEntity;
import net.mcreator.exdeorumex.block.entity.CobblestoneMachineBlockEntity;
import net.mcreator.exdeorumex.block.entity.CobblestoneMachine3BlockEntity;
import net.mcreator.exdeorumex.ExdeorumExMod;

public class ExdeorumExModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ExdeorumExMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> COBBLESTONE_MACHINE = register("cobblestone_machine", ExdeorumExModBlocks.COBBLESTONE_MACHINE, CobblestoneMachineBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COBBLESTONE_MACHINES_2 = register("cobblestone_machines_2", ExdeorumExModBlocks.COBBLESTONE_MACHINES_2, CobblestoneMachines2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COBBLESTONE_MACHINE_3 = register("cobblestone_machine_3", ExdeorumExModBlocks.COBBLESTONE_MACHINE_3, CobblestoneMachine3BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> DIRT_MACHINE = register("dirt_machine", ExdeorumExModBlocks.DIRT_MACHINE, DirtMachineBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> DIRT_MACHINE_2 = register("dirt_machine_2", ExdeorumExModBlocks.DIRT_MACHINE_2, DirtMachine2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> DIRT_MACHINE_3 = register("dirt_machine_3", ExdeorumExModBlocks.DIRT_MACHINE_3, DirtMachine3BlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
