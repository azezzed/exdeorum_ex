
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.exdeorumex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.exdeorumex.ExdeorumExMod;

public class ExdeorumExModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ExdeorumExMod.MODID);
	public static final RegistryObject<CreativeModeTab> EXDEORUM_EX = REGISTRY.register("exdeorum_ex",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.exdeorum_ex.exdeorum_ex")).icon(() -> new ItemStack(ExdeorumExModItems.NETHERITE_COMPRESS_HAMMER.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DIRT.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_GRAVEL.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_SAND.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DUST.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_CRUSHED_NETHERRACK.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_CRUSHED_END_STONE.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_CRUSHED_DEEPSLATE.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_CRUSHED_BLACKSTONE.get().asItem());
				tabData.accept(ExdeorumExModItems.STONE_CHIPS.get());
				tabData.accept(ExdeorumExModItems.FLINT_CHIPS.get());
				tabData.accept(ExdeorumExModItems.DIRT_CHIPS.get());
				tabData.accept(ExdeorumExModItems.GRAVEL_CHIPS.get());
				tabData.accept(ExdeorumExModItems.SAND_CHIPS.get());
				tabData.accept(ExdeorumExModItems.DUST_CHIPS.get());
				tabData.accept(ExdeorumExModItems.NETHERRACK_CHIPS.get());
				tabData.accept(ExdeorumExModItems.END_CHIPS.get());
				tabData.accept(ExdeorumExModItems.DEEPSLATE_CHIPS.get());
				tabData.accept(ExdeorumExModItems.BLACKSTONE_CHIPS.get());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_LEAVES.get().asItem());
				tabData.accept(ExdeorumExModItems.COMPRESS_SILK_WORM.get());
				tabData.accept(ExdeorumExModItems.COMPRESS_STRING.get());
				tabData.accept(ExdeorumExModItems.COMPRESS_SEEDS.get());
				tabData.accept(ExdeorumExModItems.COMPRESS_SAPLING.get());
				tabData.accept(ExdeorumExModItems.LEAVE.get());
				tabData.accept(ExdeorumExModItems.PEAR.get());
				tabData.accept(ExdeorumExModItems.PEACH.get());
				tabData.accept(ExdeorumExModItems.NUTS.get());
				tabData.accept(ExdeorumExModItems.COOKED_NUTS.get());
				tabData.accept(ExdeorumExModItems.STONE_STICK.get());
				tabData.accept(ExdeorumExModItems.WOODEN_COMPRESS_CROOK.get());
				tabData.accept(ExdeorumExModItems.STONE_COMPRESS_CROOK.get());
				tabData.accept(ExdeorumExModItems.DOUBLE_COMPRES_STONE_CROOK.get());
				tabData.accept(ExdeorumExModItems.STEEL_HAMMER.get());
				tabData.accept(ExdeorumExModItems.WOODEN_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.STONE_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.IRON_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.GOLDEN_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.DIAMON_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.DOBLE_DIAMON_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.NETHERITE_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.DOUBLE_NETHERITE_COMPRESS_HAMMER.get());
				tabData.accept(ExdeorumExModItems.WOODEN_SHEARS.get());
				tabData.accept(ExdeorumExModItems.FLINT_SHEARS.get());
				tabData.accept(ExdeorumExModItems.DOUBLE_FLINT_SHEARS.get());
				tabData.accept(ExdeorumExModBlocks.COBBLESTONE_MACHINE.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COBBLESTONE_MACHINES_2.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COBBLESTONE_MACHINE_3.get().asItem());
				tabData.accept(ExdeorumExModBlocks.LAVA_BLOCK.get().asItem());
				tabData.accept(ExdeorumExModBlocks.WITCH_DIRT.get().asItem());
				tabData.accept(ExdeorumExModBlocks.DIRT_MACHINE.get().asItem());
				tabData.accept(ExdeorumExModBlocks.DIRT_MACHINE_2.get().asItem());
				tabData.accept(ExdeorumExModBlocks.DIRT_MACHINE_3.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_STONE_1X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_STONE_2X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_STONE_3X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_STONE_4X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_1X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_2X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_3X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_COBBLESTONE_4X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DIRT_2X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DIRT_3X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DIRT_4X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_SAND_2X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_SAND_3X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_SAND_4X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DUST_2X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DUST_3X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_DUST_4X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_GRAVEL_2X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_GRAVEL_3X.get().asItem());
				tabData.accept(ExdeorumExModBlocks.COMPRESS_GRAVEL_4X.get().asItem());
				tabData.accept(ExdeorumExModItems.STEEL_INGOT.get());
				tabData.accept(ExdeorumExModBlocks.STEEL_BLOCK.get().asItem());
			})

					.build());
}
