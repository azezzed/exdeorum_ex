
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.exdeorumex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.exdeorumex.block.WitchDirtBlock;
import net.mcreator.exdeorumex.block.SteelBlockBlock;
import net.mcreator.exdeorumex.block.LavaBlockBlock;
import net.mcreator.exdeorumex.block.DirtMachineBlock;
import net.mcreator.exdeorumex.block.DirtMachine3Block;
import net.mcreator.exdeorumex.block.DirtMachine2Block;
import net.mcreator.exdeorumex.block.CompressStone4xBlock;
import net.mcreator.exdeorumex.block.CompressStone3xBlock;
import net.mcreator.exdeorumex.block.CompressStone2xBlock;
import net.mcreator.exdeorumex.block.CompressStone1xBlock;
import net.mcreator.exdeorumex.block.CompressSandBlock;
import net.mcreator.exdeorumex.block.CompressSand4xBlock;
import net.mcreator.exdeorumex.block.CompressSand3xBlock;
import net.mcreator.exdeorumex.block.CompressSand2xBlock;
import net.mcreator.exdeorumex.block.CompressLeavesBlock;
import net.mcreator.exdeorumex.block.CompressGravelBlock;
import net.mcreator.exdeorumex.block.CompressGravel4xBlock;
import net.mcreator.exdeorumex.block.CompressGravel3xBlock;
import net.mcreator.exdeorumex.block.CompressGravel2xBlock;
import net.mcreator.exdeorumex.block.CompressDustBlock;
import net.mcreator.exdeorumex.block.CompressDust4xBlock;
import net.mcreator.exdeorumex.block.CompressDust3xBlock;
import net.mcreator.exdeorumex.block.CompressDust2xBlock;
import net.mcreator.exdeorumex.block.CompressDirtBlock;
import net.mcreator.exdeorumex.block.CompressDirt4xBlock;
import net.mcreator.exdeorumex.block.CompressDirt3xBlock;
import net.mcreator.exdeorumex.block.CompressDirt2xBlock;
import net.mcreator.exdeorumex.block.CompressCrushedNetherrackBlock;
import net.mcreator.exdeorumex.block.CompressCrushedEndStoneBlock;
import net.mcreator.exdeorumex.block.CompressCrushedDeepslateBlock;
import net.mcreator.exdeorumex.block.CompressCrushedBlackstoneBlock;
import net.mcreator.exdeorumex.block.CompressCobblestone4xBlock;
import net.mcreator.exdeorumex.block.CompressCobblestone3xBlock;
import net.mcreator.exdeorumex.block.CompressCobblestone2xBlock;
import net.mcreator.exdeorumex.block.CompressCobblestone1xBlock;
import net.mcreator.exdeorumex.block.CobblestoneMachines2Block;
import net.mcreator.exdeorumex.block.CobblestoneMachineBlock;
import net.mcreator.exdeorumex.block.CobblestoneMachine3Block;
import net.mcreator.exdeorumex.ExdeorumExMod;

public class ExdeorumExModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ExdeorumExMod.MODID);
	public static final RegistryObject<Block> COMPRESS_DIRT = REGISTRY.register("compress_dirt", () -> new CompressDirtBlock());
	public static final RegistryObject<Block> COMPRESS_GRAVEL = REGISTRY.register("compress_gravel", () -> new CompressGravelBlock());
	public static final RegistryObject<Block> COMPRESS_SAND = REGISTRY.register("compress_sand", () -> new CompressSandBlock());
	public static final RegistryObject<Block> COMPRESS_DUST = REGISTRY.register("compress_dust", () -> new CompressDustBlock());
	public static final RegistryObject<Block> COMPRESS_CRUSHED_NETHERRACK = REGISTRY.register("compress_crushed_netherrack", () -> new CompressCrushedNetherrackBlock());
	public static final RegistryObject<Block> COMPRESS_CRUSHED_END_STONE = REGISTRY.register("compress_crushed_end_stone", () -> new CompressCrushedEndStoneBlock());
	public static final RegistryObject<Block> COMPRESS_CRUSHED_DEEPSLATE = REGISTRY.register("compress_crushed_deepslate", () -> new CompressCrushedDeepslateBlock());
	public static final RegistryObject<Block> COMPRESS_CRUSHED_BLACKSTONE = REGISTRY.register("compress_crushed_blackstone", () -> new CompressCrushedBlackstoneBlock());
	public static final RegistryObject<Block> COMPRESS_LEAVES = REGISTRY.register("compress_leaves", () -> new CompressLeavesBlock());
	public static final RegistryObject<Block> COBBLESTONE_MACHINE = REGISTRY.register("cobblestone_machine", () -> new CobblestoneMachineBlock());
	public static final RegistryObject<Block> COBBLESTONE_MACHINES_2 = REGISTRY.register("cobblestone_machines_2", () -> new CobblestoneMachines2Block());
	public static final RegistryObject<Block> COBBLESTONE_MACHINE_3 = REGISTRY.register("cobblestone_machine_3", () -> new CobblestoneMachine3Block());
	public static final RegistryObject<Block> LAVA_BLOCK = REGISTRY.register("lava_block", () -> new LavaBlockBlock());
	public static final RegistryObject<Block> WITCH_DIRT = REGISTRY.register("witch_dirt", () -> new WitchDirtBlock());
	public static final RegistryObject<Block> DIRT_MACHINE = REGISTRY.register("dirt_machine", () -> new DirtMachineBlock());
	public static final RegistryObject<Block> DIRT_MACHINE_2 = REGISTRY.register("dirt_machine_2", () -> new DirtMachine2Block());
	public static final RegistryObject<Block> DIRT_MACHINE_3 = REGISTRY.register("dirt_machine_3", () -> new DirtMachine3Block());
	public static final RegistryObject<Block> COMPRESS_STONE_1X = REGISTRY.register("compress_stone_1x", () -> new CompressStone1xBlock());
	public static final RegistryObject<Block> COMPRESS_STONE_2X = REGISTRY.register("compress_stone_2x", () -> new CompressStone2xBlock());
	public static final RegistryObject<Block> COMPRESS_STONE_3X = REGISTRY.register("compress_stone_3x", () -> new CompressStone3xBlock());
	public static final RegistryObject<Block> COMPRESS_STONE_4X = REGISTRY.register("compress_stone_4x", () -> new CompressStone4xBlock());
	public static final RegistryObject<Block> COMPRESS_COBBLESTONE_1X = REGISTRY.register("compress_cobblestone_1x", () -> new CompressCobblestone1xBlock());
	public static final RegistryObject<Block> COMPRESS_COBBLESTONE_2X = REGISTRY.register("compress_cobblestone_2x", () -> new CompressCobblestone2xBlock());
	public static final RegistryObject<Block> COMPRESS_COBBLESTONE_3X = REGISTRY.register("compress_cobblestone_3x", () -> new CompressCobblestone3xBlock());
	public static final RegistryObject<Block> COMPRESS_COBBLESTONE_4X = REGISTRY.register("compress_cobblestone_4x", () -> new CompressCobblestone4xBlock());
	public static final RegistryObject<Block> COMPRESS_DIRT_2X = REGISTRY.register("compress_dirt_2x", () -> new CompressDirt2xBlock());
	public static final RegistryObject<Block> COMPRESS_DIRT_3X = REGISTRY.register("compress_dirt_3x", () -> new CompressDirt3xBlock());
	public static final RegistryObject<Block> COMPRESS_DIRT_4X = REGISTRY.register("compress_dirt_4x", () -> new CompressDirt4xBlock());
	public static final RegistryObject<Block> COMPRESS_SAND_2X = REGISTRY.register("compress_sand_2x", () -> new CompressSand2xBlock());
	public static final RegistryObject<Block> COMPRESS_SAND_3X = REGISTRY.register("compress_sand_3x", () -> new CompressSand3xBlock());
	public static final RegistryObject<Block> COMPRESS_SAND_4X = REGISTRY.register("compress_sand_4x", () -> new CompressSand4xBlock());
	public static final RegistryObject<Block> COMPRESS_DUST_2X = REGISTRY.register("compress_dust_2x", () -> new CompressDust2xBlock());
	public static final RegistryObject<Block> COMPRESS_DUST_3X = REGISTRY.register("compress_dust_3x", () -> new CompressDust3xBlock());
	public static final RegistryObject<Block> COMPRESS_DUST_4X = REGISTRY.register("compress_dust_4x", () -> new CompressDust4xBlock());
	public static final RegistryObject<Block> COMPRESS_GRAVEL_2X = REGISTRY.register("compress_gravel_2x", () -> new CompressGravel2xBlock());
	public static final RegistryObject<Block> COMPRESS_GRAVEL_3X = REGISTRY.register("compress_gravel_3x", () -> new CompressGravel3xBlock());
	public static final RegistryObject<Block> COMPRESS_GRAVEL_4X = REGISTRY.register("compress_gravel_4x", () -> new CompressGravel4xBlock());
	public static final RegistryObject<Block> STEEL_BLOCK = REGISTRY.register("steel_block", () -> new SteelBlockBlock());
}
